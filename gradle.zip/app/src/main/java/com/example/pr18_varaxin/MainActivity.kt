package com.example.pr18_varaxin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    private lateinit var prefsManager: SharedPreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefsManager = SharedPreferencesManager(this)

        if (savedInstanceState == null) {
            if (prefsManager.getUsername() != null) {
                navigateToTaskList()
            } else {
                navigateToAuth()
            }
        }
    }

    fun navigateToAuth() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, AuthFragment())
            .commit()
    }

    fun navigateToTaskList() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, TaskListFragment())
            .commit()
    }

    fun navigateToAddTask() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, AddTaskFragment())
            .addToBackStack(null)
            .commit()
    }
}