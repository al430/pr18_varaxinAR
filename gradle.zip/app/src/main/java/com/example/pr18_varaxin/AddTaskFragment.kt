package com.example.pr18_varaxin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import java.util.UUID

class AddTaskFragment : Fragment() {
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var etTaskTitle: EditText
    private lateinit var etTaskDesc: EditText
    private lateinit var btnSaveTask: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_add_task, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefsManager = SharedPreferencesManager(requireContext())
        etTaskTitle = view.findViewById(R.id.etTaskTitle)
        etTaskDesc = view.findViewById(R.id.etTaskDesc)
        btnSaveTask = view.findViewById(R.id.btnSaveTask)

        btnSaveTask.setOnClickListener {
            val title = etTaskTitle.text.toString().trim()
            val description = etTaskDesc.text.toString().trim()

            if (title.isEmpty()) {
                Toast.makeText(requireContext(), "Введите название задачи", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val task = Task(
                id = UUID.randomUUID().toString(),
                title = title,
                description = description,
                createdAt = System.currentTimeMillis()
            )

            prefsManager.addTask(task)
            Toast.makeText(requireContext(), "Задача сохранена", Toast.LENGTH_SHORT).show()

            etTaskTitle.text.clear()
            etTaskDesc.text.clear()

            (activity as? MainActivity)?.navigateToTaskList()
        }
    }
}
