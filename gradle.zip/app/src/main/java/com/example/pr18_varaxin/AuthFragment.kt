package com.example.pr18_varaxin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment

class AuthFragment : Fragment() {
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var etUsername: EditText
    private lateinit var btnLogin: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_auth, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefsManager = SharedPreferencesManager(requireContext())
        etUsername = view.findViewById(R.id.etUsername)
        btnLogin = view.findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()

            if (username.isEmpty()) {
                Toast.makeText(requireContext(), "Введите ваше имя", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            prefsManager.saveUsername(username)
            Toast.makeText(requireContext(), "Добро пожаловать, $username!", Toast.LENGTH_SHORT).show()

            (activity as? MainActivity)?.navigateToTaskList()
        }
    }
}
