package com.example.pr18_varaxin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TaskListFragment : Fragment() {
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var tvWelcome: TextView
    private lateinit var rvTasks: RecyclerView
    private lateinit var btnAddTask: Button
    private lateinit var btnLogout: Button
    private lateinit var adapter: TaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_task_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefsManager = SharedPreferencesManager(requireContext())
        tvWelcome = view.findViewById(R.id.tvWelcome)
        rvTasks = view.findViewById(R.id.rvTasks)
        btnAddTask = view.findViewById(R.id.btnAddTask)
        btnLogout = view.findViewById(R.id.btnLogout)

        val username = prefsManager.getUsername()
        tvWelcome.text = if (username != null) "Привет, $username!" else "Привет!"

        adapter = TaskAdapter(
            emptyList(),
            onTaskClick = { task ->
                showTaskDetails(task)
            },
            onTaskLongClick = { task ->
                showDeleteDialog(task)
            }
        )

        rvTasks.layoutManager = LinearLayoutManager(requireContext())
        rvTasks.adapter = adapter

        loadTasks()

        btnAddTask.setOnClickListener {
            (activity as? MainActivity)?.navigateToAddTask()
        }

        btnLogout.setOnClickListener {
            showLogoutDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        loadTasks()
    }

    private fun loadTasks() {
        val tasks = prefsManager.getTasks()
        adapter.updateTasks(tasks)
    }

    private fun showTaskDetails(task: Task) {
        AlertDialog.Builder(requireContext())
            .setTitle(task.title)
            .setMessage(if (task.description.isNotEmpty()) task.description else "Нет описания")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showDeleteDialog(task: Task) {
        AlertDialog.Builder(requireContext())
            .setTitle("Удалить задачу")
            .setMessage("Вы уверены, что хотите удалить задачу \"${task.title}\"?")
            .setPositiveButton("Да") { _, _ ->
                prefsManager.deleteTask(task.id)
                loadTasks()
            }
            .setNegativeButton("Нет", null)
            .show()
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Выход")
            .setMessage("Вы уверены, что хотите выйти?")
            .setPositiveButton("Да") { _, _ ->
                prefsManager.clearUsername()
                (activity as? MainActivity)?.navigateToAuth()
            }
            .setNegativeButton("Нет", null)
            .show()
    }
}
