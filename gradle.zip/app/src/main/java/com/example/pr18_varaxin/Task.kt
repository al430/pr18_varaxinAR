package com.example.pr18_varaxin

data class Task(
    var id: String,
    var title: String,
    var description: String,
    var createdAt: Long
)
